# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['audio_utils']

package_data = \
{'': ['*']}

install_requires = \
['indic-nlp-library>=0.92,<0.93',
 'moviepy>=1.0.3,<2.0.0',
 'mutagen>=1.47.0,<2.0.0',
 'pydub>=0.25.1,<0.26.0']

setup_kwargs = {
    'name': 'audio-utils',
    'version': '0.1.0',
    'description': 'This package contain the audio utility methods',
    'long_description': None,
    'author': 'munikumar.mm',
    'author_email': 'munikumar.m09@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
